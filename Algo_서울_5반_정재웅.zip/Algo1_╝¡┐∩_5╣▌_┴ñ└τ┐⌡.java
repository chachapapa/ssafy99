import java.util.Arrays;
import java.util.Scanner;

public class Algo1_서울_5반_정재웅 {
	public static void main(String[] args) {

		
		//n = 배열 길이 3<= n <=100
		//m = 지진발생횟수 1<= m <= 20
		
		Scanner sc = new Scanner(System.in);
		
		int t = sc.nextInt();
		
		for(int test = 1 ; test<=t ; test++) {
			
			//나라 크기
			int n = sc.nextInt();
			
			//지진횟수
			int m = sc.nextInt();
			
			//나라 크기를 배열로 받아줍니다.
			int[] land = new int[n];
			
			//지진횟수에 따른 반복문을 for문으로 설정해줍니다.
			for(int time = 0; time<m ; time++) {
				
			//지진위치
			int root = sc.nextInt()-1;
			
			//강도
			int power = sc.nextInt();
			
			
			//지진위치에서 1칸씩 멀어질때 1씩 복구비용이 줄어드므로
			//지진위치와 구하고자하는 위치의 인덱스값의 차이를 절댓값으로 구하여
			//강도에 차감합니다.
			//복구비용이 음수가되는 경우는 불가능하므로
			//강도가 1 이상인경우만 설정해줍니다.
				for(int i = 0; i<n ; i++) {
					if(power-Math.abs(root-i)>0) {
					land[i] += power-Math.abs(root-i);
					}
				}
			
			}
			
			//이후 sum변수를 설정하여 모든 땅의 비용을 합산해 출력합니다.
			int sum = 0;
			for(int i = 0; i<n ; i++) {
				sum += land[i];
			}
			System.out.println("#"+test+" "+sum);
		}
		
	}
}
