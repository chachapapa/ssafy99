import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Algo2_서울_5반_정재웅 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int t = sc.nextInt();

		for (int test = 1; test <= t; test++) {

			// 땅크기
			int n = sc.nextInt();

			int[][] land = new int[n][n];
			
			//각 변의 크기가 n 인 2중배열 생성 후 
			//위치별 영양소를 받아줌
			for (int x = 0; x < n; x++) {
				for (int y = 0; y < n; y++) {

					land[x][y] = sc.nextInt();

				}
			}

			// 마법 사용횟수
			int s = sc.nextInt();
			// 마법 사용 횟수에 따른 반복문 for문으로 작성.
			for (int time = 0; time < s; time++) {
				// 행
				int row = sc.nextInt();

				// 열
				int column = sc.nextInt();

				// 범위
				int range = sc.nextInt();

				// 마법종류
				int magic = sc.nextInt();
				
				
				//마법의 종류 백, 흑, 잿빛 각 경우를 if문으로 설정해줍니다.
				
				//먼저 백마법의 경우에는 for문을 통해 행 열의 최솟값과 최댓값으로
				//해당위치에서 범위를 뻰 값과 더한 값으로 설정해준 뒤
				//땅에서 벗어나지 않는 범위에 한해 
				//그 효과인 2배를 적용시킵니다.
				//이 때 중앙의 마법 위치에서는 두번 적용되므로
				//따로 2로 나누어줍니다.
				//또한 2배할 위치의 값이 0일 경우 1이 되도록 
				//if문을 하나 더 삽입하여 주었습니다.
				if (magic == 0) {
					for (int x = row - range; x <= row + range; x++) {
						if (x >= 0 && x < n) {
							land[x][column] *= 2;
							if (land[x][column] == 0) {
								land[x][column]++;
							}
						}
					}
					for (int y = column - range; y <= column + range; y++) {
						if (y >= 0 && y < n) {
							land[row][y] *= 2;
							if (land[row][y] == 0) {
								land[row][y]++;
							}
						}
					}
					
					
					land[row][column] /= 2;

					
					
					//흑마법의 경우에는 
					//델타값을 사용하여 해결하였습니다.
					
					
				} else if (magic == 1) {
					
					//range값에 맞게 list에 각 대각선위치의 땅을 지정할 수 있도록
					//네가지 경우의 수를 넣어줍니다.
					List<Integer> dx = new ArrayList<>();
					List<Integer> dy = new ArrayList<>();
					for (int addx = 1; addx <= range; addx++) {
						dx.add(-addx);
						dx.add(addx);
						dx.add(-addx);
						dx.add(addx);
					}


					for (int addy = 1; addy <= range; addy++) {
						dy.add(addy);
						dy.add(-addy);
						dy.add(-addy);
						dy.add(addy);
					}

					//각 경우가 land의 범위에서 벗어나지 않도록 if 문을 설정해주고
					//모든 조건을 충족할 시에는 /2 를 해주는 for문을 작성합니다.
					//몫을 구했기 때문에 자연스럽게 소숫점은 떨어집니다.
					for (int bm = 0; bm < dx.size(); bm++) {
						if (row + dx.get(bm) >= 0 && row + dx.get(bm) < n && column + dy.get(bm) >= 0
								&& column + dy.get(bm) < n) {
							land[row + dx.get(bm)][column + dy.get(bm)] /= 2;
						}
					}

					//이때 0을 범위에 포함할 시에는 
					//네번이나 해당위치의 값이 나누어지므로
					//마법 시전위치에서의 효과는 따로 설정해줍니다. 
					land[row][column] /= 2;

					
					//잿빛마법의 경우는 위 두가지의 경우를 합쳤습니다.
				} else if (magic == 2) {
					for (int x = row - range; x <= row + range; x++) {
						if (x >= 0 && x < n) {
							land[x][column] *= 2;
							if (land[x][column] == 0) {
								land[x][column]++;
							}
						}
					}
					for (int y = column - range; y <= column + range; y++) {
						if (y >= 0 && y < n) {
							land[row][y] *= 2;
							if (land[row][y] == 0) {
								land[row][y]++;
							}
						}
					}

					
					List<Integer> dx = new ArrayList<>();
					List<Integer> dy = new ArrayList<>();
					for (int addx = 1; addx <= range; addx++) {
						dx.add(-addx);
						dx.add(addx);
						dx.add(-addx);
						dx.add(addx);
					}


					for (int addy = 1; addy <= range; addy++) {
						dy.add(addy);
						dy.add(-addy);
						dy.add(-addy);
						dy.add(addy);
					}

					for (int bm = 0; bm < dx.size(); bm++) {
						if (row + dx.get(bm) >= 0 && row + dx.get(bm) < n && column + dy.get(bm) >= 0
								&& column + dy.get(bm) < n) {
							land[row + dx.get(bm)][column + dy.get(bm)] /= 2;
						}
					}
					
					//다만 별개로 지정해둔 시전위치에서의 경우를 위해
					//백마법 시전시 두번 실행된 경우와
					//흑마법 시전시 시전되지 않은 경우를 위해
					//4로 나눈 값을 넣어줍니다.
					land[row][column] /= 4;
					for (int x = 0; x < n; x++) {

					}
				}
				
			}
			
			//이후 sum변수에 2중배열의 각 위치내 값을 모두 더해 출력합니다.
			
			int sum = 0;
			for(int x = 0 ; x< n ;x++) {
				for(int y = 0 ; y<n ;y++) {
					
					sum += land[x][y]; 
				}
			}
				System.out.println("#"+test+" "+sum);
		}

	}

}
